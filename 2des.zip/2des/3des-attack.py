import base64
from Crypto.Cipher import DES

# Hàm mã hóa DES
def des_encrypt(key, plaintext):
    cipher = DES.new(key, DES.MODE_ECB)
    padded_text = plaintext + (8 - len(plaintext) % 8) * ' '
    encrypted = cipher.encrypt(padded_text.encode('utf-8'))
    return base64.b64encode(encrypted).decode('utf-8')

# Hàm giải mã DES
def des_decrypt(key, ciphertext):
    cipher = DES.new(key, DES.MODE_ECB)
    encrypted_bytes = base64.b64decode(ciphertext)
    try:
        decrypted = cipher.decrypt(encrypted_bytes)
        return decrypted.decode('utf-8', errors='ignore').rstrip()
    except Exception as e:
        return None  # Trả về None nếu có lỗi

# Hàm tấn công Meet-in-the-Middle cho 3DES với ba khóa
def meet_in_the_middle_attack_3keys(ciphertext, plaintext, keys1_file, keys2_file, keys3_file):
    with open(keys1_file, 'r') as f:
        keys1 = [line.strip().encode('utf-8') for line in f.readlines()]
    with open(keys2_file, 'r') as f:
        keys2 = [line.strip().encode('utf-8') for line in f.readlines()]
    with open(keys3_file, 'r') as f:
        keys3 = [line.strip().encode('utf-8') for line in f.readlines()]

    encrypt_dict = {}
    print("Đang thử các khóa trong keys1.txt...")
    for key1 in keys1:
        intermediate1 = des_encrypt(key1, plaintext)
        if intermediate1:  # Bỏ qua kết quả None
            encrypt_dict[intermediate1] = key1
            print(f"Key1: {key1.decode('utf-8')} -> Intermediate1: {intermediate1}")

    decrypt_dict = {}
    print("\nĐang thử các khóa trong keys3.txt...")
    for key3 in keys3:
        intermediate3 = des_decrypt(key3, ciphertext)
        if intermediate3:  # Bỏ qua kết quả None
            decrypt_dict[intermediate3] = key3
            print(f"Key3: {key3.decode('utf-8')} -> Intermediate3: {intermediate3}")

    print("\nĐang thử các khóa trong keys2.txt...")
    for key2 in keys2:
        for intermediate1 in encrypt_dict:
            decrypted = des_decrypt(key2, intermediate1)
            if decrypted and decrypted in decrypt_dict:  # Bỏ qua None và kiểm tra khớp
                found_key1 = encrypt_dict[intermediate1]
                found_key3 = decrypt_dict[decrypted]
                return found_key1, key2, found_key3

    return None, None, None

# Chương trình chính
if __name__ == "__main__":
    # Tạo các file khóa (cần chuẩn bị trước keys1.txt, keys2.txt, keys3.txt)
    keys1_file = "keys1.txt"
    keys2_file = "keys2.txt"
    keys3_file = "keys3.txt"

    # Thiết lập plaintext và ciphertext
    plaintext = input("Nhập plaintext (dạng chuỗi, ví dụ: Hello123): ").strip()
    ciphertext = input("Nhập ciphertext (3DES): ").strip()

    # Tấn công Meet-in-the-Middle
    found_key1, found_key2, found_key3 = meet_in_the_middle_attack_3keys(
        ciphertext, plaintext, keys1_file, keys2_file, keys3_file
    )

    if found_key1 and found_key2 and found_key3:
        print("\nTấn công 3DES thành công. Khóa tìm được:")
        print("Key1:", found_key1.decode('utf-8'))
        print("Key2:", found_key2.decode('utf-8'))
        print("Key3:", found_key3.decode('utf-8'))
    else:
        print("\nTấn công 3DES không thành công. Không tìm thấy bộ khóa phù hợp!")
