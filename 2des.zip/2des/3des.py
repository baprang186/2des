from Crypto.Cipher import DES
import base64

# Hàm tạo đối tượng DES để mã hóa
def des_encrypt(key, plaintext):
    cipher = DES.new(key, DES.MODE_ECB)
    # Padding để đảm bảo plaintext có độ dài là bội số của 8
    padded_text = plaintext + (8 - len(plaintext) % 8) * ' '
    encrypted = cipher.encrypt(padded_text.encode('utf-8'))
    return base64.b64encode(encrypted).decode('utf-8')

# Hàm tạo đối tượng DES để giải mã
def des_decrypt(key, ciphertext):
    cipher = DES.new(key, DES.MODE_ECB)
    encrypted_bytes = base64.b64decode(ciphertext)
    decrypted = cipher.decrypt(encrypted_bytes)
    try:
        # Giải mã thành công
        return decrypted.decode('utf-8').rstrip()
    except UnicodeDecodeError:
        # Trả về giá trị thô nếu không giải mã được
        return decrypted

# Mã hóa 3DES với cấu trúc K1=K3
def triple_des_encrypt(key1, key2, plaintext):
    # Bước 1: Mã hóa với key1 (E_K1)
    intermediate1 = des_encrypt(key1, plaintext)
    # Bước 2: Giải mã với key2 (D_K2)
    intermediate2 = des_decrypt(key2, intermediate1)
    # Bước 3: Mã hóa lại với key1 (E_K1)
    if isinstance(intermediate2, bytes):  # Kiểm tra nếu đầu ra là bytes
        intermediate2 = base64.b64encode(intermediate2).decode('utf-8')
    return des_encrypt(key1, intermediate2)

# Giải mã 3DES với cấu trúc K1=K3
def triple_des_decrypt(key1, key2, ciphertext):
    # Bước 1: Giải mã với key1 (D_K1)
    intermediate1 = des_decrypt(key1, ciphertext)
    # Bước 2: Mã hóa với key2 (E_K2)
    if isinstance(intermediate1, bytes):  # Kiểm tra nếu đầu ra là bytes
        intermediate1 = base64.b64encode(intermediate1).decode('utf-8')
    intermediate2 = des_encrypt(key2, intermediate1)
    # Bước 3: Giải mã lại với key1 (D_K1)
    return des_decrypt(key1, intermediate2)

# Chương trình chính
if __name__ == "__main__":
    # Nhập khóa
    key1_input = input("Nhập khóa key1 (K1=K3, độ dài 8 byte): ").strip()
    key1 = key1_input.encode()
    if len(key1) != 8:
        raise ValueError("Khóa K1 phải có độ dài chính xác 8 byte!") 

    key2_input = input("Nhập khóa key2 (độ dài 8 byte): ").strip()
    key2 = key2_input.encode()
    if len(key2) != 8:
        raise ValueError("Khóa K2 phải có độ dài chính xác 8 byte!") 

    # Nhập plaintext
    plaintext = input("Nhập plaintext: ").strip()

    # Mã hóa với 3DES
    ciphertext = triple_des_encrypt(key1, key2, plaintext)
    print("\nCiphertext (3DES):", ciphertext)

    # Giải mã với 3DES
    decrypted_text = triple_des_decrypt(key1, key2, ciphertext)
    print("Decrypted text (3DES):", decrypted_text)
